const express=require("express");
const ejs = require('ejs');
const app=express();

app.set('view engine', 'ejs');
app.use(express.json());
app.use(express.urlencoded({ extended: true}))
app.use(express.static("Public"));

var items=[];
items.push({ptitle: "title", text: "text"});


app.get('/', (req,res)=>{
    res.render("index",{items: items});
})

app.get('/new', (req,res)=>{
    res.render("newpost");
});

app.post('/Submit_', (req,res)=>{
    var ptitle = req.body.ptitle;
    var text = req.body.text;
    
    var Texto = {ptitle: ptitle, text: text};
    items.push(Texto);
    res.render("index",{items:items});
});

app.listen(3000,()=>{
	console.log("Example app listening on part 3000");
});